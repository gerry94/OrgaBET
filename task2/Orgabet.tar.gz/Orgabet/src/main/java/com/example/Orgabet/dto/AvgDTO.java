package com.example.Orgabet.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Iterator;

@ToString
@Getter
@Setter
public class AvgDTO
{
	private String id;
	private Double avg;
}
