package com.example.Orgabet.dto;

import lombok.*;

@Getter
@Setter
public class EditProfileDTO {
  String firstName;
  String lastName;
  boolean banned;

}
