package com.example.Orgabet.dto;

import lombok.*;

@Getter
@Setter
@ToString
public class countDTO {
	private String id;
	private Double count;
}
