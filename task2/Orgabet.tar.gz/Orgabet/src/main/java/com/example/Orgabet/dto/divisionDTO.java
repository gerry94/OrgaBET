package com.example.Orgabet.dto;

import java.util.List;

import lombok.*;

@Getter
@Setter
@ToString
public class divisionDTO {
	public String id;
	public String division;
}
