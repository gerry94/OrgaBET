package com.example.Orgabet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrgabetApplicationTests {

	@Test
	void contextLoads() {
	}

}
